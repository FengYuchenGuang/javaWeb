create definer = root@localhost view emp_view01 as
select `hsp_db03`.`emp05`.`empno`  AS `empno`,
       `hsp_db03`.`emp05`.`ename`  AS `ename`,
       `hsp_db03`.`emp05`.`job`    AS `job`,
       `hsp_db03`.`emp05`.`deptno` AS `deptno`
from `hsp_db03`.`emp05`;

