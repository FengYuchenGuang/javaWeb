create definer = root@localhost view emp_view03 as
select `hsp_db03`.`emp05`.`empno`    AS `empno`,
       `hsp_db03`.`emp05`.`ename`    AS `ename`,
       `hsp_db03`.`dept`.`dname`     AS `dname`,
       `hsp_db03`.`salgrade`.`grade` AS `grade`
from `hsp_db03`.`emp05`
         join `hsp_db03`.`dept`
         join `hsp_db03`.`salgrade`
where ((`hsp_db03`.`emp05`.`deptno` = `hsp_db03`.`dept`.`deptno`) and
       (`hsp_db03`.`emp05`.`sal` between `hsp_db03`.`salgrade`.`losal` and `hsp_db03`.`salgrade`.`hisal`));

