create
    definer = root@localhost function rand_string(n int) returns varchar(255)
BEGIN
	#定义了一个变量 chars_str， 类型 varchar(100)
	#默认给 chars_str 初始值 'abcdefghijklmnopqrstuvwxyzABCDEFJHIJKLMNOPQRSTUVWXYZ' 
	DECLARE chars_str VARCHAR(100) DEFAULT
		'abcdefghijklmnopqrstuvwxyzABCDEFJHIJKLMNOPQRSTUVWXYZ';
	DECLARE return_str VARCHAR(255) DEFAULT '';
	DECLARE i INT DEFAULT 0;
	WHILE i < n DO
		# concat 函数 : 连接函数 mysql 函数
		SET return_str = CONCAT(return_str,SUBSTRING(chars_str,FLOOR(1+RAND()*52),1));
		SET i = i + 1;
	END WHILE;
	RETURN return_str;
END;

